INTRODUCTION
------------

This module contains custom content type, custom block and custom twig.


INSTALLATION
------------

It is simple module which need to install from extend section of admin.


CONFIGURATION
-------------

Once this module is enable, one content type will be automatically created named as "Jugaad Patches Products".

Also one custom block will be automatically enabled and it also automatically palced on "Sidebar second" of Bartik theme.

Once some node has been added into "Jugaad Patches Products" content type. One listing page will be generated automatically on "$base_url/product-listing".

From listing page you can select any product and then detail page of particualar product will come and their you can scan QR code form mobile or any other device and after scan it will automatically redirect to respective URL which is written in node edit mode.


MAINTAINERS
-----------

- Dhruv Panchal (https://www.drupal.org/u/dhruv-panchal)
