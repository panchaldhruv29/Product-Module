<?php
/**
 * @file
 * Contains \Drupal\jugaad_patches\Plugin\Block\ProductQRCodeBlock.
 */
namespace Drupal\jugaad_patches\Plugin\Block;
use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'article' block.
 *
 * @Block(
 *   id = "product_qr_code",
 *   admin_label = @Translation("Product QR Code block"),
 *   category = @Translation("Custom Product QR Code block")
 * )
 */

class ProductQRCodeBlock extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {
    $node = \Drupal::routeMatch()->getParameter('node');
    if ($node instanceof \Drupal\node\NodeInterface) {
      // You can get nid and anything else you need from the node object.
      $nid = $node->id();
    }
		$node = \Drupal\node\Entity\Node::load($nid);
		$product_link = '<img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl='.$node->field_product_link->value.'" title="Link to Google.com" />';
    return [
      '#markup' => $product_link,
    ];
  }

  /**
   * @return int
   */
  public function getCacheMaxAge() {
    return 0;
  }
}
