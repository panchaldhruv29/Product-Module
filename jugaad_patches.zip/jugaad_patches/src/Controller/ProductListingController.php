<?php

namespace Drupal\jugaad_patches\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * An example controller.
 */
class ProductListingController extends ControllerBase {

  /**
   * Returns a render-able array for a test page.
   */
  public function product_listing() {
    global $base_url;
  	$query = \Drupal::entityQuery('node')
       ->condition('status', 1)
       ->condition('type', 'jugaad_patches')
       ->pager(10);
      $nids = $query->execute();
  	foreach ($nids as $nid) {
  		$node = \Drupal\node\Entity\Node::load($nid);
      $product['url'] =  $base_url.'/node/'.$nid;
  		$product['body'] = $node->body->value;
  		$product['title'] = $node->title->value;
  		$avatar = $node->get('field_product_image')->entity->getFileUri();
  		if ($wrapper = \Drupal::service('stream_wrapper_manager')->getViaUri($avatar)) {
  			$product['avatar'] = $wrapper->getExternalUrl();
  		}
      $product_array[] = $product;
  	}
    $output = [
      '#theme' => 'product_listing',
      '#product' => $product_array,
    ];
    return $output;
  }
}
